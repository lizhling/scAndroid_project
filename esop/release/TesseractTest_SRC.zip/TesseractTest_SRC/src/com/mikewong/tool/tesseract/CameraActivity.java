package com.mikewong.tool.tesseract;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.PixelFormat;
import android.graphics.drawable.BitmapDrawable;
import android.hardware.Camera;
import android.hardware.Camera.AutoFocusCallback;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.Size;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.text.Html;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

import com.googlecode.tesseract.android.TessBaseAPI;
/**
 * 拍照识别demo
 * @author guoh
 *
 */
public class CameraActivity extends Activity implements OnClickListener,SurfaceHolder.Callback {
	private static final String TAG = "CameraActivity";
	private static final int STATUS_WIDTH=760;
	private static final int STAUS_HEIGHT=480;
	private static int[][] cutPoints = {{130,45,256,110},
		{185,118,225,185},
		{300,110,385,185},
		{145,175,460,240},
		{150,240,485,360},
		{260,370,740,460}};
	private static String cancle;
	private static String error;
	private SurfaceView cameraSurfaceView;
	private Camera mCamera;

	private SurfaceHolder holder;

	private ImageButton btnShutter;
	private Button btnCancle;
	private Button btnRetake;
	private Button btnDone;
	private Button btnSend;
	private ImageView photoView;
	private ImageView imgFocus;
	private String cameraFront = Environment.getExternalStorageDirectory()+File.separator+"idcardImage.jpg";
	private int focusHeight;
	private int focusWidth;
	private int frameWidth;
	private int frameHeight;
	private ProgressDialog progressDialog;
	private TextView resultText;
	private TextView txtRemark;
	private String resultStr=null;
	private String[] mPepoleIdLabelArray;  
	Bitmap mBitmap = null;
	private Handler mHandler = new Handler() {
		public void handleMessage(Message msg) {
			if(progressDialog!=null)
				progressDialog.dismiss();
			switch (msg.what) {
			case 1:
				Toast.makeText(CameraActivity.this, getString(R.string.save_photo_success), Toast.LENGTH_SHORT).show();
				/*StringBuilder result = new StringBuilder("<b>"+getString(R.string.asyns_pic_result)+"</b>");
				if(resultStr!=null&&!resultStr.startsWith("err")&&resultStr.indexOf(",")>-1) {
					String[] values = resultStr.split(",");
					if(values.length>=6) {
						for(int i=0;i<mPepoleIdLabelArray.length;i++){
							String value="<br>"+mPepoleIdLabelArray[i]+values[i];
							result.append(value);
						}
					}else {
						result.append("<br>").append(resultStr);
					}
				}else {
					result.append("<br>").append(resultStr);
				}*/
				if(resultStr!=null)
				resultText.setText(Html.fromHtml(resultStr));
				resultText.setVisibility(View.VISIBLE);
				photoView.setVisibility(View.GONE);
				cameraSurfaceView.setVisibility(View.GONE);
				btnSend.setVisibility(View.VISIBLE);
				break;
			default:
				break;
			}

		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.camera);
			cancle=getString(R.string.english_cancle);
			error=getString(R.string.english_error);			
			initView();		
			mPepoleIdLabelArray=getResources().getStringArray(R.array.people_id);
			Log.d(TAG, "onCreate is called");
	}

	private void initView() {
		cameraSurfaceView = (SurfaceView) findViewById(R.id.camera_preview);
		photoView = (ImageView) findViewById(R.id.image_capture_preview);
		photoView.setVisibility(View.GONE);
		cameraSurfaceView.setVisibility(View.VISIBLE);

		holder = cameraSurfaceView.getHolder();
		holder.addCallback(this);
		holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		
		LayoutInflater inflater = getLayoutInflater();
		ViewGroup rootView = (ViewGroup) findViewById(R.id.camera);
		 View controlBar = inflater.inflate(
		            R.layout.attach_camera_control, rootView);
		btnCancle=(Button) controlBar.findViewById(R.id.btn_cancel);
		btnCancle.setOnClickListener(new OnClickListener() {				
			@Override
			public void onClick(View v) {
				sendResultBroadcast(cancle);
			}
		});
		
		btnShutter = (ImageButton) controlBar.findViewById(R.id.btn_shutter);
		btnShutter.setOnClickListener(this);
		
		btnRetake = (Button) controlBar.findViewById(R.id.btn_retake);
		btnRetake.setVisibility(View.GONE);
		btnRetake.setOnClickListener(this);
		
		btnSend=(Button) findViewById(R.id.btn_send);
		btnSend.setVisibility(View.GONE);
		btnSend.setOnClickListener(this);
		
		btnDone = (Button) controlBar.findViewById(R.id.btn_done);
		btnDone.setOnClickListener(this);
		btnDone.setVisibility(View.GONE);
		
		progressDialog = new ProgressDialog(this);
		progressDialog.setMessage(getString(R.string.analysising_imgage_message));
		
		resultText = (TextView)findViewById(R.id.resultText);
		txtRemark = (TextView)findViewById(R.id.txt_remark);
		imgFocus = (ImageView)findViewById(R.id.image_focus);
	}
	
	@Override
	protected void onStop() {
		super.onStop();
		closeCamera();
	}

	protected void onResume() {
		super.onResume();
	}

	
	public void surfaceCreated(SurfaceHolder holder) {
		openCamera();
	}

	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		Parameters parameters = mCamera.getParameters();
		parameters.setPictureFormat(PixelFormat.JPEG);
		mCamera.setParameters(parameters);
	}

	public void surfaceDestroyed(SurfaceHolder holder) {
		closeCamera();
	}

	private PictureCallback pictureCallback = new PictureCallback() {

		public void onPictureTaken(byte[] data, Camera camera) {
			getIntent().putExtra("bytes", data);
			mBitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
			//mBitmap=zoomBitmap(mBitmap, frameWidth, frameHeight);
			photoView.setDrawingCacheEnabled(true);
			photoView.setImageBitmap(mBitmap);
			photoView.setVisibility(View.VISIBLE);
			imgFocus.setVisibility(View.GONE);
			cameraSurfaceView.setVisibility(View.GONE);			
			closeCamera();
		}
	};
	
	private void closeCamera() {
		if(mCamera!=null){
			mCamera.stopPreview();			
			mCamera.release();
			mCamera = null;
		}
	}
	
	
	public void onClick(View v) {
		try {
			String status=Environment.getExternalStorageState();
			if(!status.equals(Environment.MEDIA_MOUNTED)) {
				Toast.makeText(CameraActivity.this, getString(R.string.please_inser_sd), Toast.LENGTH_LONG);
				return ;
			}
			if (v.getId() == R.id.btn_shutter) {
				resultStr=null;
				mBitmap=null;
				resultText.setVisibility(View.GONE);
				takePicture();
			} else if (v.getId() == R.id.btn_retake) {
				photoView.setVisibility(View.GONE);
				cameraSurfaceView.setVisibility(View.VISIBLE);
				resultText.setVisibility(View.GONE);
				btnDone.setVisibility(View.GONE);
				btnRetake.setVisibility(View.GONE);
				btnSend.setVisibility(View.GONE);
				btnShutter.setVisibility(View.VISIBLE);
				txtRemark.setVisibility(View.VISIBLE);
				resultStr=null;
				photoView.setImageBitmap(null);
				openCamera();
			} else if (v.getId() == R.id.btn_done) {
				btnRetake.setVisibility(View.VISIBLE);
				btnShutter.setVisibility(View.GONE);
				btnDone.setVisibility(View.GONE);
				resultText.setVisibility(View.GONE);
				handlePicture();
			} else if (v.getId() == R.id.btn_send) {
				sendResultBroadcast(resultStr);
			} else {
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void takePicture() {
		List<String> focusModes = mCamera.getParameters().getSupportedFocusModes();
		if(focusModes == null||!focusModes.contains(Camera.Parameters.FOCUS_MODE_AUTO)) {
			cameraTakePicture();
		}else {
			mCamera.autoFocus(new AutoFocusCallback() {
				public void onAutoFocus(boolean success, Camera camera) {
					if(success) {
						cameraTakePicture();
						mCamera.cancelAutoFocus();
					}
				}
			});
   }
	}

	private void cameraTakePicture(){
		mCamera.takePicture(null, null, pictureCallback);
		imgFocus.setVisibility(View.GONE);
		btnDone.setVisibility(View.VISIBLE);
		btnRetake.setVisibility(View.VISIBLE);
		btnShutter.setVisibility(View.GONE);
		txtRemark.setVisibility(View.GONE);
	}
	
	private void handlePicture() {
		resultStr=error;
		progressDialog.show();
		new Thread() {
			public void run() {
				try {
					mBitmap=photoView.getDrawingCache();
					mBitmap=Bitmap.createBitmap(mBitmap,imgFocus.getLeft(), imgFocus.getTop(), imgFocus.getWidth(), imgFocus.getHeight());
					savePicture(mBitmap,cameraFront);
					photoView.setDrawingCacheEnabled(false);
					int width = mBitmap.getWidth();
					int height = mBitmap.getHeight();
					for(int i=0;i<cutPoints.length;i++){
						int[] subBitmapRegion=cutPoints[i];
						int x = width * subBitmapRegion[0] / STATUS_WIDTH;
						int y = height * subBitmapRegion[1] / STAUS_HEIGHT;
						int cutWidth = width * (subBitmapRegion[2]-subBitmapRegion[0]) / STATUS_WIDTH;
						int cutHeight = height * (subBitmapRegion[3]-subBitmapRegion[1]) / STAUS_HEIGHT;
						Bitmap subBitmap=Bitmap.createBitmap(mBitmap, x, y, cutWidth, cutHeight);  
						//savePicture(subBitmap,getSDPath()+File.separator+"subpng"+i+".jpg");
						subBitmap = ImgPretreatment.doPretreatment(subBitmap);
						resultStr+=doOcr(subBitmap, "chi_sim");
					}					
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					mHandler.sendEmptyMessage(1);
				}
			}
		}.start();
	}

	/**
	 * 获取sd卡的路径
	 * 
	 * @return 路径的字符串
	 */
	public static String getSDPath() {
		File sdDir = null;
		boolean sdCardExist = Environment.getExternalStorageState().equals(
				android.os.Environment.MEDIA_MOUNTED); // 判断sd卡是否存在
		if (sdCardExist) {
			sdDir = Environment.getExternalStorageDirectory();// 获取外存目录
		}
		return sdDir.toString();
	}
	
	/**
	 * 进行图片识别
	 * 
	 * @param bitmap
	 *            待识别图片
	 * @param language
	 *            识别语言
	 * @return 识别结果字符串
	 */
 	public String doOcr(Bitmap bitmap, String language) {
		TessBaseAPI baseApi = new TessBaseAPI();

		baseApi.init(getSDPath(), language);

		// 必须加此行，tess-two要求BMP必须为此配置
		Bitmap bitmapCopy;
		bitmapCopy = bitmap.copy(Bitmap.Config.ARGB_8888, true);

		baseApi.setImage(bitmapCopy);

		String text = baseApi.getUTF8Text();

		baseApi.clear();
		baseApi.end();

		return text;
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}

    private void sendResultBroadcast(String value){
	/*	if(value.contains("err"))
			value=error;
    	Intent intent = new Intent(ThirdPartyDevice.READ_ID_BY_CAMERA_BROADCAST);
    	intent.putExtra(JavaScriptConfig.EXTRAL_ID_INFO, value);
		sendBroadcast(intent);
		finish();*/
    }
    
	private void openCamera() {
		if (mCamera == null)
			mCamera = Camera.open();
		try {
			Size size = setCameraParameters();		
			setGreenBox(size);
		} catch (IOException e) {
			e.printStackTrace();
			mCamera.release();
			mCamera = null;

		}
	}

	private Size setCameraParameters() throws IOException {
		Camera.Parameters parameters = mCamera.getParameters();// 获得相机参数
		Size size = parameters.getPictureSize();	
		// Set a preview size that is closest to the viewfinder height and has
		// the right aspect ratio.
		List<Size> sizes = parameters.getSupportedPreviewSizes();
		Size optimalSize = getOptimalPreviewSize(
				sizes, (double) size.width / size.height);
		if (optimalSize != null) {
			Size original = parameters.getPreviewSize();
			if (!original.equals(optimalSize)) {
				parameters.setPreviewSize(optimalSize.width, optimalSize.height);
				frameWidth=optimalSize.width;
				frameHeight=optimalSize.height;
				// Zoom related settings will be changed for different preview
				// sizes, so set and read the parameters to get lastest values
				mCamera.setParameters(parameters);
				parameters = mCamera.getParameters();
			}
		}

		mCamera.setParameters(parameters);// 设置相机参数
		mCamera.setPreviewDisplay(holder);
		mCamera.startPreview();
		return size;
	}

	 public Bitmap zoomBitmap(Bitmap bitmap, int width, int height) {
	        if (bitmap == null) {
	            return null;
	        }
	        int w = bitmap.getWidth();
	        int h = bitmap.getHeight();
	        Matrix matrix = new Matrix();
	        float scaleWidth = ((float) width / w);
	        float scaleHeight = ((float) height / h);
	        matrix.postScale(scaleWidth, scaleHeight);
	        Bitmap newbmp = Bitmap.createBitmap(bitmap, 0, 0, w, h, matrix, true);
	        return newbmp;
	    }
	 
	private void setGreenBox(Size size) {
		PreviewFrameLayout frameLayout =
				(PreviewFrameLayout) findViewById(R.id.frame_layout);
		frameLayout.setAspectRatio((double) size.width / size.height);
		
		int h = frameLayout.getHeight();
		focusHeight = (int)(h*0.7);
		focusWidth =(int)(focusHeight*1.5852);

		DisplayMetrics metric = new DisplayMetrics();  
		getWindowManager().getDefaultDisplay().getMetrics(metric);  
		
		imgFocus.setLayoutParams(new LayoutParams(focusWidth, focusHeight));
		imgFocus.setVisibility(View.VISIBLE);
	}
	
    private Size getOptimalPreviewSize(List<Size> sizes, double targetRatio) {
        final double ASPECT_TOLERANCE = 0.05;
        if (sizes == null) return null;

        Size optimalSize = null;
        double minDiff = Double.MAX_VALUE;

        // Because of bugs of overlay and layout, we sometimes will try to
        // layout the viewfinder in the portrait orientation and thus get the
        // wrong size of mSurfaceView. When we change the preview size, the
        // new overlay will be created before the old one closed, which causes
        // an exception. For now, just get the screen size

        Display display = getWindowManager().getDefaultDisplay();
        int targetHeight = Math.min(display.getHeight(), display.getWidth());

        if (targetHeight <= 0) {
            // We don't know the size of SurefaceView, use screen height
            WindowManager windowManager = (WindowManager)
                    getSystemService(Context.WINDOW_SERVICE);
            targetHeight = windowManager.getDefaultDisplay().getHeight();
        }

        // Try to find an size match aspect ratio and size
        for (Size size : sizes) {
            double ratio = (double) size.width / size.height;
            if (Math.abs(ratio - targetRatio) > ASPECT_TOLERANCE) continue;
            if (Math.abs(size.height - targetHeight) < minDiff) {
                optimalSize = size;
                minDiff = Math.abs(size.height - targetHeight);
            }
        }

        // Cannot find the one match the aspect ratio, ignore the requirement
        if (optimalSize == null) {
            minDiff = Double.MAX_VALUE;
            for (Size size : sizes) {
                if (Math.abs(size.height - targetHeight) < minDiff) {
                    optimalSize = size;
                    minDiff = Math.abs(size.height - targetHeight);
                }
            }
        }
        return optimalSize;
    }
    
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
    	// TODO Auto-generated method stub
    	super.onConfigurationChanged(newConfig);
    }
    
	private  String savePicture(Bitmap bitmap,String photo){
		String ret = "";
	    BufferedOutputStream os = null;
		try {
			os = new BufferedOutputStream(new FileOutputStream(new File(photo)));
			if(bitmap!=null)
			bitmap.compress(CompressFormat.JPEG, 100, os);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(os!=null)
					os.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return ret;
	}
	
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if(keyCode==KeyEvent.KEYCODE_BACK){
			sendResultBroadcast(cancle);
		}
		return super.onKeyDown(keyCode, event);
	}
}
